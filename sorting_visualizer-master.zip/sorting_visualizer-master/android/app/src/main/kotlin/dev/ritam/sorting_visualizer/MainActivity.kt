package dev.ritam.sorting_visualizer

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
